﻿using NUnit.Framework;

namespace FlaUI.Core.UITests.Patterns
{
    [TestFixture]
    [Ignore("Need a sample app which provides this")]
    public class DockPatternTests
    {
        // TODO
    }
}

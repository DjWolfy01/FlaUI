﻿namespace FlaUI.Core.UITests.TestFramework
{
    public enum TestApplicationType
    {
        Custom,
        WinForms,
        Wpf
    }
}

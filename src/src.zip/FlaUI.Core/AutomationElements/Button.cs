﻿using FlaUI.Core.AutomationElements.PatternElements;

namespace FlaUI.Core.AutomationElements
{
    public class Button : InvokeAutomationElement
    {
        public Button(BasicAutomationElementBase basicAutomationElement) : base(basicAutomationElement)
        {
        }
    }
}

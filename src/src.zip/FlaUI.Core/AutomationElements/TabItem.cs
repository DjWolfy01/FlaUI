﻿using FlaUI.Core.AutomationElements.PatternElements;

namespace FlaUI.Core.AutomationElements
{
    public class TabItem : SelectionItemAutomationElement
    {
        public TabItem(BasicAutomationElementBase basicAutomationElement) : base(basicAutomationElement)
        {
        }
    }
}

﻿using System.Linq;
using FlaUI.Core.AutomationElements.Infrastructure;
using FlaUI.Core.Patterns;

namespace FlaUI.Core.AutomationElements.PatternElements
{
    /// <summary>
    /// Base class for a selection item.
    /// </summary>
    /// <typeparam name="TItem">The type of the inner items.</typeparam>
    public abstract class SelectionAutomationElement<TItem> : AutomationElement where TItem : SelectionItemAutomationElement
    {
        protected SelectionAutomationElement(BasicAutomationElementBase basicAutomationElement) : base(basicAutomationElement)
        {
        }

        protected ISelectionPattern SelectionPattern => Patterns.Selection.Pattern;

        public bool CanSelectMultiple => SelectionPattern.CanSelectMultiple.Value;

        public bool IsSelectionRequired => SelectionPattern.IsSelectionRequired.Value;

        /// <summary>
        /// Gets all selected items.
        /// </summary>
        public TItem[] Selection => SelectionPattern.Selection.Value.Select(CreateItem).ToArray();

        public TItem SelectByIndex(int index)
        {
            Items[index].Select();
        }

        public TItem SelectByText(string textToFind)
        {
            foreach (var item in Items)
            {
                item.
            }
        }

        protected abstract TItem[] Items { get; }

        protected abstract TItem CreateItem(AutomationElement itemElement);
    }
}

﻿using FlaUI.Core.AutomationElements.PatternElements;

namespace FlaUI.Core.AutomationElements
{
    public class RadioButton : SelectionItemAutomationElement
    {
        public RadioButton(BasicAutomationElementBase basicAutomationElement) : base(basicAutomationElement)
        {
        }
    }
}

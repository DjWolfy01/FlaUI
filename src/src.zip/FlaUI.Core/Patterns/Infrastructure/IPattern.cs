﻿namespace FlaUI.Core.Patterns.Infrastructure
{
    public interface IPattern
    {
    }
}

﻿namespace FlaUI.Core
{
    public enum FrameworkType
    {
        None,
        Unknown,
        Wpf,
        WinForms,
        Win32,
        Xaml
    }
}

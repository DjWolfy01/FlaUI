﻿namespace FlaUI.Core
{
    public interface ITextRange2 : ITextRange
    {
        void ShowContextMenu();
    }
}

﻿namespace FlaUI.Core.Definitions
{
    public enum PropertyConditionFlags
    {
        None = 0,
        IgnoreCase = 1
    }
}

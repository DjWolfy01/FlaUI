﻿namespace FlaUI.Core.Definitions
{
    public enum WindowVisualState
    {
        Normal = 0,
        Maximized = 1,
        Minimized = 2
    }
}

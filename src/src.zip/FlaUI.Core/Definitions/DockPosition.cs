﻿namespace FlaUI.Core.Definitions
{
    public enum DockPosition
    {
        Top = 0,
        Left = 1,
        Bottom = 2,
        Right = 3,
        Fill = 4,
        None = 5
    }
}

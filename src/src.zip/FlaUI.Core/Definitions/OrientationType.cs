﻿namespace FlaUI.Core.Definitions
{
    public enum OrientationType
    {
        None = 0,
        Horizontal = 1,
        Vertical = 2
    }
}

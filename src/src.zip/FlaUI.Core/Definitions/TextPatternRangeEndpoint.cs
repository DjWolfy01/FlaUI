﻿namespace FlaUI.Core.Definitions
{
    public enum TextPatternRangeEndpoint
    {
        Start = 0,
        End = 1
    }
}

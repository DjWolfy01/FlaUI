﻿namespace FlaUI.Core.Definitions
{
    public enum SupportedTextSelection
    {
        None = 0,
        Single = 1,
        Multiple = 2
    }
}

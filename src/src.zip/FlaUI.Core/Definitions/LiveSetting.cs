﻿namespace FlaUI.Core.Definitions
{
    public enum LiveSetting
    {
        Off = 0,
        Polite = 1,
        Assertive = 2
    }
}

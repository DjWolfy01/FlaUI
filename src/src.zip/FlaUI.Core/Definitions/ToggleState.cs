﻿namespace FlaUI.Core.Definitions
{
    public enum ToggleState
    {
        Off = 0,
        On = 1,
        Indeterminate = 2
    }
}

﻿namespace FlaUI.Core.Definitions
{
    public enum ExpandCollapseState
    {
        Collapsed = 0,
        Expanded = 1,
        PartiallyExpanded = 2,
        LeafNode = 3
    }
}

﻿namespace FlaUI.Core.Definitions
{
    public enum ScrollAmount
    {
        LargeDecrement = 0,
        SmallDecrement = 1,
        NoAmount = 2,
        LargeIncrement = 3,
        SmallIncrement = 4
    }
}

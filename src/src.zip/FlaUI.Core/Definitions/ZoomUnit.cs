﻿namespace FlaUI.Core.Definitions
{
    public enum ZoomUnit
    {
        NoAmount = 0,
        LargeDecrement = 1,
        SmallDecrement = 2,
        LargeIncrement = 3,
        SmallIncrement = 4
    }
}

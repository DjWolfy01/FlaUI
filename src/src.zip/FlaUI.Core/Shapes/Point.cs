﻿using System;
using FlaUI.Core.Tools;
using FlaUI.Core.WindowsAPI;

namespace FlaUI.Core.Shapes
{
    /// <summary>
    /// UI-independent implementation of a point
    /// </summary>
    public class Point : ShapeBase
    {
        /// <summary>
        /// Exact x-coordinate
        /// </summary>
        public double X { get; set; }

        /// <summary>
        /// Exact y-coordinate
        /// </summary>
        public double Y { get; set; }

        /// <summary>
        /// Gets a value indicating whether this point is empty (all coordinates are 0)
        /// </summary>
        public bool IsEmpty => Equals(EmptyPoint);

        public Point(double x, double y)
        {
            X = x;
            Y = y;
        }

        /// <summary>
        /// Calculates the distance to the other given point
        /// </summary>
        public double Distance(Point otherPoint)
        {
            return Distance(otherPoint.X, otherPoint.Y);
        }

        public double Distance(double otherX, double otherY)
        {
            return Math.Sqrt(Math.Pow(X - otherX, 2) + Math.Pow(Y - otherY, 2));
        }

        public override int GetHashCode()
        {
            unchecked
            {
                // ReSharper disable NonReadonlyMemberInGetHashCode
                return X.GetHashCode() * 397 ^ Y.GetHashCode();
                // ReSharper restore NonReadonlyMemberInGetHashCode
            }
        }

        public override bool Equals(object other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            if (other.GetType() != GetType()) return false;
            return Equals((Point)other);
        }

        public bool Equals(Point other)
        {
            return X.Equals(other.X) && Y.Equals(other.Y);
        }

        /// <summary>
        /// Implicit conversion to GDI point
        /// </summary>
        public static implicit operator System.Drawing.Point(Point p)
        {
            return new System.Drawing.Point(p.X.ToInt(), p.Y.ToInt());
        }

        /// <summary>
        /// Implicit conversion from GDI point
        /// </summary>
        public static implicit operator Point(System.Drawing.Point p)
        {
            return new Point(p.X, p.Y);
        }

        /// <summary>
        /// Implicit conversion to WPF point
        /// </summary>
        public static implicit operator System.Windows.Point(Point p)
        {
            return new System.Windows.Point(p.X, p.Y);
        }

        /// <summary>
        /// Implicit conversion from WPF point
        /// </summary>
        public static implicit operator Point(System.Windows.Point p)
        {
            return new Point(p.X, p.Y);
        }

        /// <summary>
        /// Implicit conversion to native point
        /// </summary>
        public static implicit operator POINT(Point p)
        {
            return new POINT { X = p.X.ToInt(), Y = p.Y.ToInt() };
        }

        /// <summary>
        /// Implicit conversion from native point
        /// </summary>
        public static implicit operator Point(POINT p)
        {
            return new Point(p.X, p.Y);
        }

        public override string ToString()
        {
            return $"X={X},Y={Y}";
        }

        /// <summary>
        /// Instance of an empty point
        /// </summary>
        public static Point EmptyPoint = new Point(0, 0);
    }
}

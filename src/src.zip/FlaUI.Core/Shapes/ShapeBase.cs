﻿namespace FlaUI.Core.Shapes
{
    /// <summary>
    /// Base class for coordinate based shapes
    /// </summary>
    public abstract class ShapeBase
    {
    }
}

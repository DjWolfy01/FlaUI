﻿namespace FlaUI.Core
{
    public enum AutomationType
    {
        UIA2,
        UIA3
    }
}

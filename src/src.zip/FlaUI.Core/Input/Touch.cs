﻿namespace FlaUI.Core.Input
{
    public static class Touch
    {
    }
}

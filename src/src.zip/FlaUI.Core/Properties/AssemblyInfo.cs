using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FlaUI.Core")]
[assembly: AssemblyDescription("Library with base elements used in the concrete implementations of FlaUI.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Roemer")]
[assembly: AssemblyProduct("FlaUI")]
[assembly: AssemblyCopyright("Copyright © 2016-2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("0224cee1-30c0-4539-b609-bcf2b38a8870")]

[assembly: AssemblyVersion("1.0.0")]
[assembly: AssemblyFileVersion("1.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]

[assembly: InternalsVisibleTo("FlaUI.Core.UnitTests")]
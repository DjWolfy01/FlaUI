using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FlaUI.UIA3")]
[assembly: AssemblyDescription("Library to use FlaUI with UIA3.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Roemer")]
[assembly: AssemblyProduct("FlaUI")]
[assembly: AssemblyCopyright("Copyright © 2016-2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("49952cc0-b938-4306-888e-836e247b0768")]

[assembly: AssemblyVersion("1.0.0")]
[assembly: AssemblyFileVersion("1.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
